git add .
git commit -m "auto_update"
git push